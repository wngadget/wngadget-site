// Track WhatsApp click for Pixel Lead event
document.querySelectorAll('a[href*="wa.link"]').forEach(btn => {
  btn.addEventListener('click', () => {
    try { fbq('track', 'Lead'); } catch(e) {}
  });
});
